# -*- coding: utf-8 -*-
"""
Created on Thu Dec 14 08:33:08 2023

@author: EstudianteDAM206
"""
import os
import sqlite3

#Conexion a la base de datos y creacion del cursor/puntero
#-------------------------------------
ruta=os.path.join("C:/Users/EstudianteDAM206/Desktop/CRMSistemas","bbdd.db")

conexionbbdd= sqlite3.connect(ruta)

cursor=conexionbbdd.cursor();
#-------------------------------------

#Creacion de una tabla empresa para probar, funciona correctamente
#-------------------------------------
cursor.execute("Create table empresa2 (nombre varchar(50), contraseña varchar(30), localidad varchar(50), telefono varchar(9))")
#-------------------------------------
#Creacion de un registro de prueba en l abbdd, funciona correctamente
#-------------------------------------
empresa=[('Taller manolito','Carricoche','Valladolid','123 45 67 89')] 
cursor.executemany("INSERT INTO EMPRESA2 VALUES (?,?,?,?)",empresa)
#-------------------------------------
#Confirmacion de los cambios, necesario para que los datos se almacenen en la bbdd
conexionbbdd.commit()
#Cierre de la conexion con la bbdd
conexionbbdd.close()